#!/usr/bin/env python3
# aionet_phase2.py - Network flow to application mapping

import psutil
import threading
import time
from collections import defaultdict

# === GLOBAL DATA ===
port_to_app = {}      # {port: app_name}
app_to_ports = defaultdict(set)  # {app_name: {port1, port2, ...}}
lock = threading.Lock()

def update_port_app_mapping():
    """Map network ports to applications using psutil"""
    temp_port_map = {}
    temp_app_ports = defaultdict(set)
    
    try:
        connections = psutil.net_connections(kind='inet')
        
        for conn in connections:
            if conn.status == psutil.CONN_ESTABLISHED and conn.laddr and conn.pid:
                try:
                    proc = psutil.Process(conn.pid)
                    app_name = proc.name()
                    
                    # Map local port to app
                    local_port = conn.laddr.port
                    temp_port_map[local_port] = app_name
                    temp_app_ports[app_name].add(local_port)
                    
                    # Also map remote port (for incoming connections)
                    if conn.raddr:
                        remote_port = conn.raddr.port
                        temp_port_map[remote_port] = app_name
                        temp_app_ports[app_name].add(remote_port)
                        
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
                    
        with lock:
            port_to_app.clear()
            port_to_app.update(temp_port_map)
            app_to_ports.clear()
            app_to_ports.update(temp_app_ports)
            
    except Exception as e:
        print(f"[!] Port mapping error: {e}")

def monitor_port_mapping():
    """Continuously update port-to-app mapping"""
    while True:
        update_port_app_mapping()
        
        with lock:
            print(f"[PORT-MAP] Active apps: {list(app_to_ports.keys())}")
            
        time.sleep(3)

# Test Phase 2
if __name__ == "__main__":
    print("🔄 Phase 2: Testing port-to-app mapping")
    
    threading.Thread(target=monitor_port_mapping, daemon=True).start()
    
    try:
        while True:
            time.sleep(5)
            with lock:
                sample_mappings = dict(list(port_to_app.items())[:5])
                print(f"Sample port mappings: {sample_mappings}")
    except KeyboardInterrupt:
        print("✅ Phase 2 complete")

