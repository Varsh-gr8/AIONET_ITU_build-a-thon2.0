from flask import Flask, render_template, request, redirect
import sqlite3
from datetime import datetime

app = Flask(__name__)

priority_map = {"High": 3, "Medium": 2, "Low": 1}
base_traffic = [
    {"app": "Zoom", "priority": "High"},
    {"app": "YouTube", "priority": "Medium"},
    {"app": "Google Drive", "priority": "Low"}
]

def init_db():
    conn = sqlite3.connect('aionet.db')
    c = conn.cursor()
    c.execute('''CREATE TABLE IF NOT EXISTS feedback (
                    id INTEGER PRIMARY KEY,
                    app_name TEXT,
                    current_priority TEXT,
                    override_priority TEXT,
                    timestamp TEXT
                )''')
    conn.commit()
    conn.close()

def get_latest_overrides():
    conn = sqlite3.connect('aionet.db')
    c = conn.cursor()
    c.execute('''
        SELECT app_name, override_priority FROM feedback
        WHERE id IN (
            SELECT MAX(id) FROM feedback GROUP BY app_name
        )
    ''')
    overrides = {row[0]: row[1] for row in c.fetchall()}
    conn.close()
    return overrides

@app.route('/')
def dashboard():
    overrides = get_latest_overrides()
    traffic_data = []
    for entry in base_traffic:
        app = entry["app"]
        priority = overrides.get(app, entry["priority"])
        traffic_data.append({
            "app": app,
            "priority": priority,
            "score": priority_map[priority]
        })
    return render_template("dashboard.html", traffic=traffic_data)

@app.route('/override', methods=['POST'])
def override():
    app_name = request.form['app_name']
    current_priority = request.form['current_priority']
    override_priority = request.form['override_priority']
    timestamp = datetime.now().strftime("%Y-%m-%d %H:%M:%S")

    conn = sqlite3.connect('aionet.db')
    c = conn.cursor()
    c.execute("INSERT INTO feedback (app_name, current_priority, override_priority, timestamp) VALUES (?, ?, ?, ?)",
              (app_name, current_priority, override_priority, timestamp))
    conn.commit()
    conn.close()

    return redirect('/')

if __name__ == "__main__":
    init_db()
    app.run(debug=True)


