import subprocess
import time
import threading
from collections import defaultdict
import psutil
import random
from scapy.all import sniff, IP, TCP, UDP
from datetime import datetime

# === GLOBAL DATA ===
application_cpu = {}              # {app_name: cpu_percentage}
port_to_app = {}                  # {port: app_name}
app_to_ports = defaultdict(set)   # {app_name: set(ports)}
flow_stats = {}                   # {(src_ip, dst_ip, port): {pkt_count, total_size, first_seen}}
lock = threading.Lock()

# === PRIORITY COMPUTATION FUNCTIONS ===
def compute_application_priority(app_name, app_cpu, bandwidth_kbps, pkt_count, avg_pkt_size):
    cpu_score = min(app_cpu / 50.0, 1.0)
    bw_score = min(bandwidth_kbps / 5000.0, 1.0)
    pkt_score = min(pkt_count / 200.0, 1.0)
    size_score = min(avg_pkt_size / 1500.0, 1.0)

    base_score = 0.4 * cpu_score + 0.3 * bw_score + 0.2 * pkt_score + 0.1 * size_score
    bonus = 0.0

    if app_name != "unknown":
        name = app_name.lower()
        if any(x in name for x in ['zoom', 'teams', 'meet', 'skype']):
            bonus = 0.2
        elif any(x in name for x in ['ssh', 'terminal', 'vim']):
            bonus = 0.15
        elif any(x in name for x in ['chrome', 'firefox', 'brave']):
            bonus = 0.1

    total_score = base_score + bonus

    if total_score > 0.7:
        return "high"
    elif total_score > 0.4:
        return "medium"
    else:
        return "low"

def handle_unknown_traffic(dport, bandwidth_kbps, pkt_count):
    if dport in [22, 3389, 5900]:
        return "high", "interactive_remote"
    elif dport in [443, 8443] and bandwidth_kbps > 2000:
        return "high", "video_streaming"
    elif dport in [80, 443, 8080] and pkt_count > 20:
        return "medium", "web_traffic"
    elif dport in [25, 587, 993, 143]:
        return "medium", "email"
    elif pkt_count > 100 and bandwidth_kbps < 100:
        return "low", "background_sync"
    elif dport > 49152:
        return "low", "ephemeral"
    else:
        return "low", "unclassified"

# === CPU USAGE COLLECTION ===
def parse_top_output():
    try:
        result = subprocess.run(['top', '-b', '-n', '1'], capture_output=True, text=True, timeout=5)
        app_cpu_map = defaultdict(float)
        lines = result.stdout.split('\n')
        process_started = False
        for line in lines:
            if 'PID USER' in line:
                process_started = True
                continue
            if process_started and line.strip():
                try:
                    parts = line.split()
                    if len(parts) >= 12:
                        cpu_percent = float(parts[8])
                        command = parts[11]
                        app_cpu_map[command] += cpu_percent
                except (ValueError, IndexError):
                    continue
        return dict(app_cpu_map)
    except Exception as e:
        print(f"[!] Top parsing error: {e}")
        return {}

def monitor_application_cpu():
    while True:
        try:
            new_cpu_data = parse_top_output()
            with lock:
                application_cpu.clear()
                application_cpu.update(new_cpu_data)
            top_apps = sorted(new_cpu_data.items(), key=lambda x: x[1], reverse=True)[:5]
            print(f"[TOP-CPU] {top_apps}")
        except Exception as e:
            print(f"[!] CPU monitor error: {e}")
        time.sleep(5)

# === PORT TO APPLICATION MAPPING ===
def update_port_app_mapping():
    temp_port_map = {}
    temp_app_ports = defaultdict(set)
    try:
        connections = psutil.net_connections(kind='inet')
        for conn in connections:
            if conn.status == psutil.CONN_ESTABLISHED and conn.laddr and conn.pid:
                try:
                    proc = psutil.Process(conn.pid)
                    app_name = proc.name()
                    local_port = conn.laddr.port
                    temp_port_map[local_port] = app_name
                    temp_app_ports[app_name].add(local_port)
                    if conn.raddr:
                        remote_port = conn.raddr.port
                        temp_port_map[remote_port] = app_name
                        temp_app_ports[app_name].add(remote_port)
                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue
        with lock:
            port_to_app.clear()
            port_to_app.update(temp_port_map)
            app_to_ports.clear()
            app_to_ports.update(temp_app_ports)
    except Exception as e:
        print(f"[!] Port mapping error: {e}")

def monitor_port_mapping():
    while True:
        update_port_app_mapping()
        with lock:
            print(f"[PORT-MAP] Active apps: {list(app_to_ports.keys())}")
        time.sleep(3)

# === FLOW PACKET EVALUATION ===
def capture_real_flows():
    def process_packet(pkt):
        if IP in pkt and (TCP in pkt or UDP in pkt):
            l4 = pkt[TCP] if TCP in pkt else pkt[UDP]
            dst_port = l4.dport
            src_ip = pkt[IP].src
            dst_ip = pkt[IP].dst
            pkt_len = len(pkt)

            flow_key = (src_ip, dst_ip, dst_port)
            now = datetime.now()

            with lock:
                if flow_key not in flow_stats:
                    flow_stats[flow_key] = {"pkt_count": 0, "total_size": 0, "first_seen": now}

                flow_stats[flow_key]["pkt_count"] += 1
                flow_stats[flow_key]["total_size"] += pkt_len

                pkt_count = flow_stats[flow_key]["pkt_count"]
                total_size = flow_stats[flow_key]["total_size"]
                duration = max((now - flow_stats[flow_key]["first_seen"]).total_seconds(), 1)

                bandwidth_kbps = (total_size * 8) / (duration * 1000)  # kbps
                avg_pkt_size = total_size / pkt_count

                app_name = port_to_app.get(dst_port, "unknown")
                cpu = application_cpu.get(app_name, 0.0) if app_name != "unknown" else 0.0

                if app_name == "unknown":
                    priority, category = handle_unknown_traffic(dst_port, bandwidth_kbps, pkt_count)
                    print(f"[ALERT] Unknown flow {flow_key} ({category}) → Priority: {priority}")
                else:
                    priority = compute_application_priority(app_name, cpu, bandwidth_kbps, pkt_count, avg_pkt_size)
                    print(f"[FLOW] {app_name} {flow_key} → Priority: {priority}")

    sniff(filter="ip", prn=process_packet, store=0)

# === MAIN EXECUTION ===
if __name__ == "__main__":
    print("🔄 AIONET Stage One: Real-Time Agent + Per-Flow Evaluator")
    threading.Thread(target=monitor_application_cpu, daemon=True).start()
    threading.Thread(target=monitor_port_mapping, daemon=True).start()
    threading.Thread(target=capture_real_flows, daemon=True).start()

    try:
        while True:
            time.sleep(10)
            with lock:
                snapshot_cpu = dict(list(application_cpu.items())[:3])
                snapshot_ports = dict(list(port_to_app.items())[:5])
                print("\n=== Real-Time Snapshot ===")
                print(f"CPU Stats: {snapshot_cpu}")
                print(f"Port Mappings: {snapshot_ports}")
    except KeyboardInterrupt:
        print("✅ AIONET Agent gracefully shut down.")

