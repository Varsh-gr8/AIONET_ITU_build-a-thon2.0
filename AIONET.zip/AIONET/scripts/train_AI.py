#!/usr/bin/env python3
# aionet_agent_loop.py - Real-Time CPU + Port-to-App Mapping Agent

import subprocess
import json
import time
import threading
from collections import defaultdict
import psutil

# === GLOBAL DATA ===
application_cpu = {}         # {app_name: cpu_percentage}
port_to_app = {}             # {port: app_name}
app_to_ports = defaultdict(set)  # {app_name: set(ports)}
lock = threading.Lock()

# === PHASE 1: CPU USAGE COLLECTION ===
def parse_top_output():
    """Extract per-application CPU usage from top command"""
    try:
        result = subprocess.run(['top', '-b', '-n', '1'], 
                                capture_output=True, text=True, timeout=5)

        app_cpu_map = defaultdict(float)
        lines = result.stdout.split('\n')

        process_started = False
        for line in lines:
            if 'PID USER' in line:
                process_started = True
                continue

            if process_started and line.strip():
                try:
                    parts = line.split()
                    if len(parts) >= 12:
                        cpu_percent = float(parts[8])
                        command = parts[11]
                        app_cpu_map[command] += cpu_percent
                except (ValueError, IndexError):
                    continue

        return dict(app_cpu_map)
    except Exception as e:
        print(f"[!] Top parsing error: {e}")
        return {}

def monitor_application_cpu():
    while True:
        try:
            new_cpu_data = parse_top_output()
            with lock:
                application_cpu.clear()
                application_cpu.update(new_cpu_data)

            top_apps = sorted(new_cpu_data.items(), key=lambda x: x[1], reverse=True)[:5]
            print(f"[TOP-CPU] {top_apps}")

        except Exception as e:
            print(f"[!] CPU monitor error: {e}")

        time.sleep(3)

# === PHASE 2: PORT TO APPLICATION MAPPING ===
def update_port_app_mapping():
    temp_port_map = {}
    temp_app_ports = defaultdict(set)

    try:
        connections = psutil.net_connections(kind='inet')

        for conn in connections:
            if conn.status == psutil.CONN_ESTABLISHED and conn.laddr and conn.pid:
                try:
                    proc = psutil.Process(conn.pid)
                    app_name = proc.name()

                    local_port = conn.laddr.port
                    temp_port_map[local_port] = app_name
                    temp_app_ports[app_name].add(local_port)

                    if conn.raddr:
                        remote_port = conn.raddr.port
                        temp_port_map[remote_port] = app_name
                        temp_app_ports[app_name].add(remote_port)

                except (psutil.NoSuchProcess, psutil.AccessDenied):
                    continue

        with lock:
            port_to_app.clear()
            port_to_app.update(temp_port_map)
            app_to_ports.clear()
            app_to_ports.update(temp_app_ports)

    except Exception as e:
        print(f"[!] Port mapping error: {e}")

def monitor_port_mapping():
    while True:
        update_port_app_mapping()

        with lock:
            print(f"[PORT-MAP] Active apps: {list(app_to_ports.keys())}")

        time.sleep(3)

# === AGENT START ===
if __name__ == "__main__":
    print("🔄 Starting AIONET Agent: Real-Time CPU & Port Mapping")

    threading.Thread(target=monitor_application_cpu, daemon=True).start()
    threading.Thread(target=monitor_port_mapping, daemon=True).start()

    try:
        while True:
            time.sleep(5)
            with lock:
                sample_cpu = dict(list(application_cpu.items())[:3])
                sample_ports = dict(list(port_to_app.items())[:5])
                print("\n=== Status Snapshot ===")
                print(f"App CPU usage: {sample_cpu}")
                print(f"Port mappings: {sample_ports}")
    except KeyboardInterrupt:
        print("\n✅ Agent shutdown requested. Exiting cleanly...")

