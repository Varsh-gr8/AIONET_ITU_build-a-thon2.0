#!/usr/bin/env python3
# AIONET Dynamic Priority Engine v3.4 (With Enhanced Logging)

import json
import time
import threading
import socket
import numpy as np
import psutil
import os
import subprocess
from collections import defaultdict, deque
from scapy.all import sniff, IP, TCP, UDP
from datetime import datetime

# === CONFIGURATION ===
CONFIG_FILE = "aionet_priorities.json"
FLOW_AGING_MINUTES = 5
STATS_WINDOW = 20
DEBUG = True

# === GLOBAL STRUCTURES ===
application_cpu = {}
port_to_app = {}
app_to_ports = defaultdict(set)
flow_stats = defaultdict(lambda: {
    'pkt_count': 0,
    'total_size': 0,
    'first_seen': None,
    'last_updated': None,
    'analyzer': None
})
lock = threading.Lock()

# === DYNAMIC CONFIGURATION ===
class PriorityConfig:
    def __init__(self):
        self.app_bonuses = {}
        self.port_rules = {}
        self.protocol_weights = {}
        self.load_config()

    def load_config(self):
        try:
            if not os.path.exists(CONFIG_FILE):
                print(f"[!] Config file {CONFIG_FILE} not found. Using defaults.")
                self.set_defaults()
            else:
                with open(CONFIG_FILE) as f:
                    config = json.load(f)
                    self.app_bonuses = config.get('application_bonuses', {})
                    self.port_rules = config.get('port_rules', {})
                    self.protocol_weights = config.get('protocol_weights', {})
        except Exception as e:
            print(f"[!] Config error: {e}")
            self.set_defaults()

    def set_defaults(self):
        self.app_bonuses = {'zoom': 0.5, 'teams': 0.5, 'chrome': 0.2}
        self.port_rules = {
            "8801": {"priority": "high", "type": "video"},
            "3478": {"priority": "high", "type": "stun"}
        }
        self.protocol_weights = {'video': 0.4, 'voice': 0.3, 'http': 0.1}

priority_config = PriorityConfig()

def config_watcher():
    while True:
        priority_config.load_config()
        time.sleep(30)

# === FLOW ANALYSIS ===
class FlowAnalyzer:
    def __init__(self):
        self.packet_sizes = deque(maxlen=STATS_WINDOW)
        self.packet_times = deque(maxlen=STATS_WINDOW)
        self.protocols = set()

    def add_packet(self, pkt):
        self.packet_sizes.append(len(pkt))
        self.packet_times.append(time.time())
        if TCP in pkt and pkt[TCP].dport in [443, 8443]:
            self.protocols.add('encrypted')
        elif UDP in pkt and pkt[UDP].dport > 49152:
            self.protocols.add('ephemeral')

    @property
    def size_variance(self):
        return np.var(self.packet_sizes) if self.packet_sizes else 0

    @property
    def avg_interval(self):
        if len(self.packet_times) < 2: return 0
        return np.mean(np.diff(self.packet_times))

# === CORE FUNCTIONALITY ===
def compute_priority(app_name, flow_data):
    stats = flow_data['stats']
    analyzer = flow_data['analyzer']
    
    # Normalized metrics (0-1 range)
    cpu = min(application_cpu.get(app_name, 0) / 40, 1)  # 40% CPU = max
    bw = min(stats['bw_kbps'] / 10000, 1)  # 10Mbps = max
    pkts = min(stats['pkt_count'] / 500, 1)  # 500 packets = max
    
    # Dynamic scoring
    score = (0.5 * cpu) + (0.3 * bw) + (0.2 * pkts)
    score += priority_config.app_bonuses.get(app_name.lower(), 0)
    
    if 'encrypted' in analyzer.protocols:
        score += 0.2
    
    return "high" if score > 0.75 else "medium" if score > 0.45 else "low"

def classify_unknown(analyzer, dport):
    if analyzer.avg_interval < 0.01 and analyzer.size_variance < 50:
        return "high", "realtime"
    return priority_config.port_rules.get(str(dport), ("medium", "general"))

def process_packet(pkt):
    try:
        if IP not in pkt or (TCP not in pkt and UDP not in pkt):
            return

        l4 = pkt[TCP] if TCP in pkt else pkt[UDP]
        ip_layer = pkt[IP]
        proto = 'TCP' if TCP in pkt else 'UDP'
        flow_key = (ip_layer.src, ip_layer.dst, l4.dport)
        now = datetime.now()
        timestamp = now.strftime("%Y-%m-%d %H:%M:%S.%f")[:-3]  # Precision to milliseconds

        with lock:
            flow = flow_stats[flow_key]
            if not flow['analyzer']:
                flow['analyzer'] = FlowAnalyzer()
                flow['first_seen'] = now

            flow['analyzer'].add_packet(pkt)
            flow['pkt_count'] += 1
            flow['total_size'] += len(pkt)
            flow['last_updated'] = now

            # Calculate metrics
            duration = (now - flow['first_seen']).total_seconds()
            bw_kbps = (flow['total_size'] * 8) / max(duration, 1) / 1000
            app_name = port_to_app.get(l4.dport, "unknown")
            cpu_percent = application_cpu.get(app_name, 0.0) if app_name != "unknown" else 0.0

            # Classify priority
            if app_name == "unknown":
                priority, category = classify_unknown(flow['analyzer'], l4.dport)
                print(f"[{timestamp}] [UNKNOWN] {proto} {ip_layer.dst}:{l4.dport} ({category}) → {priority}")
            else:
                flow_data = {
                    'stats': {'bw_kbps': bw_kbps, 'pkt_count': flow['pkt_count']},
                    'analyzer': flow['analyzer']
                }
                priority = compute_priority(app_name, flow_data)
                print(f"[{timestamp}] [FLOW] {app_name} {proto} {ip_layer.dst}:{l4.dport} → {priority.upper()} (CPU: {cpu_percent:.1f}%)")

    except Exception as e:
        if DEBUG: print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}] [ERROR] {str(e)[:50]}")

# === SYSTEM MONITORS ===
def monitor_application_cpu():
    """Critical component for CPU-based prioritization"""
    while True:
        try:
            result = subprocess.run(['top', '-b', '-n1'], capture_output=True, text=True)
            cpu_data = {}
            in_processes = False
            for line in result.stdout.split('\n'):
                if 'PID' in line and 'COMMAND' in line: 
                    in_processes = True
                    continue
                if in_processes and line.strip():
                    parts = line.split()
                    if len(parts) >= 9:
                        cpu = float(parts[8])
                        cmd = parts[-1]
                        cpu_data[cmd] = cpu_data.get(cmd, 0) + cpu
            
            with lock:
                application_cpu.clear()
                application_cpu.update(cpu_data)
            
            time.sleep(5)
        except Exception as e:
            print(f"[{datetime.now().strftime('%Y-%m-%d %H:%M:%S.%f')[:-3]}] [CPU MONITOR ERROR] {e}")
            time.sleep(10)

def update_port_mapping():
    """Enhanced port mapping with UDP support"""
    conns = psutil.net_connections('inet')
    temp_map = {}
    
    for conn in conns:
        if not (conn.laddr and conn.pid): continue
        
        # Handle TCP state
        if conn.type == socket.SOCK_STREAM:
            if conn.status != psutil.CONN_ESTABLISHED: continue
        
        try:
            proc = psutil.Process(conn.pid)
            app = proc.name()
            temp_map[conn.laddr.port] = app
            if conn.raddr: 
                temp_map[conn.raddr.port] = app
        except (psutil.NoSuchProcess, psutil.AccessDenied):
            continue

    with lock:
        port_to_app.clear()
        port_to_app.update(temp_map)

def monitor_ports():
    while True:
        update_port_mapping()
        time.sleep(2)

# === MAIN ===
if __name__ == "__main__":
    print("🔄 AIONET Dynamic Priority Engine v3.4")
    
    # Start core services
    threading.Thread(target=monitor_ports, daemon=True).start()
    threading.Thread(target=monitor_application_cpu, daemon=True).start()
    threading.Thread(target=config_watcher, daemon=True).start()
    
    # Start packet processing
    sniff(prn=process_packet, filter="ip", store=False)

