#!/usr/bin/env python3
# aionet_phase1.py - CPU collection from top command

import subprocess
import json
import time
import threading
from collections import defaultdict

# === GLOBAL DATA ===
application_cpu = {}  # {app_name: cpu_percentage}
lock = threading.Lock()

def parse_top_output():
    """Extract per-application CPU usage from top command"""
    try:
        # Run top in batch mode, single iteration
        result = subprocess.run(['top', '-b', '-n', '1'], 
                              capture_output=True, text=True, timeout=5)
        
        app_cpu_map = defaultdict(float)
        lines = result.stdout.split('\n')
        
        # Find the process section (after headers)
        process_started = False
        for line in lines:
            if 'PID USER' in line:  # Header line
                process_started = True
                continue
                
            if process_started and line.strip():
                try:
                    parts = line.split()
                    if len(parts) >= 12:
                        cpu_percent = float(parts[8])  # %CPU column
                        command = parts[11]            # COMMAND column
                        
                        # Sum CPU for applications with multiple processes
                        app_cpu_map[command] += cpu_percent
                        
                except (ValueError, IndexError):
                    continue
                    
        return dict(app_cpu_map)
        
    except Exception as e:
        print(f"[!] Top parsing error: {e}")
        return {}

def monitor_application_cpu():
    """Continuously update application CPU usage from top"""
    while True:
        try:
            new_cpu_data = parse_top_output()
            
            with lock:
                application_cpu.clear()
                application_cpu.update(new_cpu_data)
            
            # Display top CPU consuming apps
            top_apps = sorted(new_cpu_data.items(), key=lambda x: x[1], reverse=True)[:5]
            print(f"[TOP-CPU] {top_apps}")
            
        except Exception as e:
            print(f"[!] CPU monitor error: {e}")
            
        time.sleep(3)  # Update every 3 seconds

# Test Phase 1
if __name__ == "__main__":
    print("🔄 Phase 1: Testing TOP-based CPU collection")
    
    # Start CPU monitoring thread
    threading.Thread(target=monitor_application_cpu, daemon=True).start()
    
    try:
        while True:
            time.sleep(5)
            with lock:
                print(f"Current app CPU: {dict(list(application_cpu.items())[:3])}")
    except KeyboardInterrupt:
        print("✅ Phase 1 complete")

