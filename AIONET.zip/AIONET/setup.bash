#!/bin/bash

# Delete existing IFB setup if already exists
sudo tc qdisc del dev wlp2s0 ingress 2>/dev/null
sudo ip link set ifb0 down 2>/dev/null
sudo ip link delete ifb0 2>/dev/null

# Load IFB module
sudo modprobe ifb

# Set up IFB
sudo ip link add ifb0 type ifb
sudo ip link set ifb0 up

# Redirect ingress from wlp2s0 to ifb0
sudo tc qdisc add dev wlp2s0 handle ffff: ingress
sudo tc filter add dev wlp2s0 parent ffff: \
    protocol ip u32 match u32 0 0 action mirred egress redirect dev ifb0

